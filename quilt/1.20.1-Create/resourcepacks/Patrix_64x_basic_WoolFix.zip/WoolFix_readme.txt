For credits, see file in Patrix original Basic pack.

===================

All this patch does is allow the Patrix basic pack to work with Sodium/iris/Continuity/Indium workaround for missing Colormatic mod
(fixes wool, concrete, terracotta) 

Please see pack load order screenshot for correct positioning of this patch/fix.