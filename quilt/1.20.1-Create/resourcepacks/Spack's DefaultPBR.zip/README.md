# Spack's DefaultPBR

Based on https://github.com/Poudingue/Vanilla-Normals-Renewed
and https://modrinth.com/mod/continuity